
#include "SellerCustomer.h"

void SellerCustomer::print() const
{
    Customer::print();
	cout << "Number of items to sell :" << _AllProducts.size() << endl;
	cout << "Number of feedbacks: " << _AllFeedbacks.getLogical() << endl;
	cout << "Average feedbacks score: " << _score << "/5 stars" << endl;
}
