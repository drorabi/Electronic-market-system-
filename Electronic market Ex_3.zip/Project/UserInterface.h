#pragma once

#ifndef __USERINTERFACE_H
#define __USERINTERFACE_H

#pragma warning (disable:4996)

#include <iostream>
#include "System.h"
#include "Product.h"
#include "UserInterface.h"
#include <time.h>
#include <ios>
#include <limits>
#include <fstream>

using namespace std;

class UserInterface {

private:
	System system;

public:

	//---------------------CONSTRUCTOR DESTRUCTOR----------------------//

	UserInterface(System system = System()) : system(system) {}
	UserInterface(const UserInterface& userinterface) :  system(userinterface.system) {}
	UserInterface(UserInterface&& userinterface);
	~UserInterface() {}

	void Run();
	void printMenu();
	void activateAction(int action);
	void cleanBuffer();

	string   defineNewUsername();
	string   defineNewPassword();
	Address  defineNewAddress();
	void     addNewUser(int type);

	void displayCustomers() const;
	void displaySellers() const;
    void displaySellerCustomer() const;
    void DisplayUsers() const;



    void                   addProductToSeller();
	string                  defineNewProductName();
	Product::eProductTypes chooseProductType();
	double                 defineProductPrice();
	Seller*                chooseSeller();

	Customer*  chooseCustomer();
	void      addProductToCustomersCart();
	Product*  chooseProduct();
	
	void makeAnOrder();
	void addFeedback();
	bool checkExistenceOfUsers() const;
	void payOrder();
	void searchProducts();
	void compareTwoCustomers();


    void getData();

    void saveData();
};


#endif //__USERINTERFACE_H