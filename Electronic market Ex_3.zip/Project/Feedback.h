#ifndef __FEEDBACK_H
#define __FEEDBACK_H

#include "Customer.h"
#include <cmath>

#pragma warning (disable:4996)


class Feedback
{
public:


	//------------------Construstor  Destructor--------------------------------//
	Feedback(const string& feedback = string(), Product* product= nullptr, Customer* customer=nullptr, int review=3,const string& date = string());
	Feedback(const Feedback& other);
	Feedback(Feedback&& other);
	


	//-----------------------------operator----------------------------------------//
	const Feedback& operator=(const Feedback& other);
	friend ostream& operator<<(ostream& os, const Feedback& feedback);

	//-------------------Setters-----------------------//
	void setContent(const string&  feedback);
	bool setReview(int review);


	//--------------------Getters----------------------//
	const string& getContent() const { return _content; }
	const string& getDate() const { return _date; }
	Product*      getProduct() const { return _product; }
	Customer*     getCustomer() { return _customer; }
	double        getReview() const { return _5StarReview; }

	//-------------------Attributes-----------------//
private:
	string       _date;
	string      _content;
	Product*   _product;
	Customer*  _customer;
	double     _5StarReview;
};

#endif // __FEEDBACK_H