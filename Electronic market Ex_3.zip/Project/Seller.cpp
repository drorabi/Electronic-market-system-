#include <iostream>
#include "Seller.h"
using namespace std;
#pragma warning (disable:4996)

//---------------------CONSTRUCTOR DESTRUCTOR-------------------//

Seller::Seller(const Seller& other) : User(other),_AllFeedbacks(Array<Feedback>())
{
	*this = other;
}
Seller::Seller(Seller && other) : User(other)
{
	_AllFeedbacks = move(other._AllFeedbacks);
	_AllProducts = other._AllProducts;
	_score = other._score;
}
Seller::~Seller()
{
	for (int i = 0;i < _AllProducts.size();i++)
		delete _AllProducts[i];
}



//-------------------PRINTING----------------------//
void Seller::print() const
{
    User::print();
	cout << "Number of items to sell: " << _AllProducts.size() << endl;
	cout << "Number of feedbacks: " << _AllFeedbacks.getLogical() << endl;
	cout << "Average feedbacks score: " << _score << "/5 stars" << endl;
}
void Seller::printProducts() const
{
	int i = 1;
	if (_AllProducts.size() == 0)
	{
		cout << "No items" << endl;
		return;
	}
	vector<Product*>::const_iterator itr = _AllProducts.begin();
	vector<Product*>::const_iterator itrEnd = _AllProducts.end();
	for (; itr != itrEnd; ++itr)
	{
		cout << "-------------ITEM #" << i << "-----------" << endl;
		cout << (**itr);
		i++;
	}
}
void Seller::printFeedbacks() const
{
	for (int i = 0;i < _AllFeedbacks.getLogical();i++)
	{
		cout << "-------------FEEDBACK #"<< i + 1 << "---------------\n";
		cout << (*_AllFeedbacks.getArray()[i]);
		cout << endl;
	}
}

//-----------------------------operator-------------------------//
const Seller & Seller::operator=(const Seller & other)
{
	if (this != &other)
	{
        _AllFeedbacks = other._AllFeedbacks;
		_AllProducts.clear();
		for (int i = 0;i < _AllProducts.size();i++)
			_AllProducts.push_back(other._AllProducts[i]);
		_score = other._score;
	}
	return *this;
}

//-----------------------ADD PRODUCT--------------------//

void Seller::addProduct(Product* newProduct)
{
	_AllProducts.push_back(newProduct);
}





