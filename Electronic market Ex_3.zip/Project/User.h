#ifndef __USER_H
#define __USER_H


#include <iostream>
#include <fstream>
#include "Address.h"
using namespace std;

#pragma warning (disable:4996)


class User
{
public:
	static int userSerialNumCounter;

	//--------------------Constructor Destructor-----------------//

	User(Address address = Address(), const string& username = string(), const string& password = string());
	User(ifstream& in);
	User(const User& other);
	User(const User&& other);
	virtual ~User() {}

	//-------------------------PRINT------------------//
	virtual void print() const = 0;

	//---------------------------Operators-----------------------//
	const User& operator=(const User& other);
	friend  ostream&operator<<(ostream& out, const User& user);

	//----------------------------Setters------------------------//
	void setUserName(const string& username);
	void setPassword(const string& password);
	void setSerialNumber();
	//------------------------Getters---------------------------//
	const string&    getUserName() const { return _username; }
	const string&    getPassWord() const { return _password; }
	Address        getAddress() const { return _address; }
	int            getSerialNum() const { return _userSerialNum; }

private:
	string   _username;
	string   _password;
	Address _address;
	int	    _userSerialNum;
};

#endif // __USER_H

