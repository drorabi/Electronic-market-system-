#include <iostream>
using namespace std;
#include "UserInterface.h"

int main()
{
	string name;
	cout << "PLEASE ENTER THE SYSTEM NAME" << endl;
	getline(cin, name);
	System system(name);
	UserInterface interface(system);
    interface.Run();
	std::system("pause");
}











