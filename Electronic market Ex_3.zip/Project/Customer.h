#ifndef __CUSTOMER_H
#define __CUSTOMER_H

#include <iostream>
#include "User.h"
#include "Address.h"
#include "Cart.h"
#include "Order.h"
#include <cmath>
#include<vector>


#pragma warning (disable:4996)

using namespace std;

class Customer : virtual public User
{
public:

	//------------------Construstor and detructor--------------------------------//

	Customer(const Address& address = Address(), const string& username = string(), const string& password = string()) : User(address, username, password), _order(Order()){}
	Customer(ifstream& in) : User(in) {}
	Customer(const Customer& other);
	Customer(Customer&& other);
	~Customer();

	//----------------------------print-----------------------//
	virtual void print() const override;
	void printShoppingHistory() const ;

	//------------------------operator-----------------------//
	const Customer& operator=(const Customer& other);
	int operator>(Customer& other);

	//------------------add product-------------------//
	void      addProductToShoppingHistory(Product* product);

	//------------------Getters--------------------//
	Cart&               getCart() { return _cart; }
	Order&		        getOrder() { return _order; }
	vector<Product*>    getShoppingHistory() const { return _shoppingHistory; }
	int                 getCurrentNumOfProdutsInShoppingHistory() const { return _shoppingHistory.size(); }


	//-------------------Attributes-----------------//
protected:

	Cart      _cart;
	vector<Product*> _shoppingHistory;
	Order	  _order;
};

#endif // Customer.h