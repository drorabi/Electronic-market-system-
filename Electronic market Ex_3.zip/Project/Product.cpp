#include <iostream>
#include "Product.h"
using namespace std;
#pragma warning (disable:4996)


int Product::productSerialNumCounter = 2000;



//--------------------CONSTRUTOR DESTRUCTOR---------------------------//
Product::Product(const string& name, eProductTypes type, double price, Seller* seller)
	:_type(type),_seller(nullptr),_serialNumber(0)
{
	bool flag;
	setProductName(name);
	setProductSerialNumber();
	flag=setProductPrice(price);
	setSeller(seller);
}
Product::Product(const Product & other)
	:_seller(nullptr)
{
	*this = other;
}
Product::Product(Product && other)
{
	*this = other;
}




//---------------------operator----------------------------//
const Product & Product::operator=(const Product & other)
{
	if (this != &other)
	{
		_name = other._name;
		_type = other._type;
		_price = other._price;
		_serialNumber = other._serialNumber;
		_seller = other._seller;
	}
	return *this;
}

ostream& operator<<(ostream& os, const Product& product)
{
		os << "Product name: " << product._name << endl << "Type: " << product.types[product._type] << endl << "Price: " << product._price << endl << "Serial number: " << product._serialNumber << endl;
		return os;
}

//---------------------Setters---------------------------//
void Product::setSeller(Seller* seller)
{
	_seller = seller;
}
void Product::setProductName(const string& name) 
{
	_name = name;
}
void Product::setProductType(Product::eProductTypes type) 
{
	_type = type;
}
bool Product::setProductPrice(double price) 
{
	if (price < 0)
		return false;
	
	_price = price;
	return true;
}
void Product::setProductSerialNumber() 
{
	_serialNumber = productSerialNumCounter;
}


