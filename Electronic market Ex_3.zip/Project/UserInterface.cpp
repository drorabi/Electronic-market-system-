#include "UserInterface.h"
#pragma warning (disable:4996)




//-------------CONSTRUCTOR DESTRUCTOR---------------------//

UserInterface::UserInterface(UserInterface&& userinterface)
{
	this->system._name = userinterface.system._name;
	this->system._currentNumOfCustomers = userinterface.system._currentNumOfCustomers;
	this->system._currentNumOfSellers = userinterface.system._currentNumOfSellers;
	this->system._currentNumOfSellerCustomer = userinterface.system._currentNumOfSellerCustomer;
	this->system._AllUsers = userinterface.system._AllUsers;
}

void UserInterface::Run()
{
    int action=1;
	cout << "~~~~~~~~~~~~~~~~~~~~~~WELCOME TO " << system.getName().c_str() << "~~~~~~~~~~~~~~~~~~~~~~" << endl;
	getData();
	while (action != 16)
    {
        printMenu();
		cout << endl;
        cout << "Please choose an action from the menu: ";
		cin >> action;
        activateAction(action);
    }

}

void UserInterface::saveData()
{
    ofstream outFile("AllUsers.txt", ios::trunc);
    outFile << system._AllUsers.size() << endl;
	vector<User*>::const_iterator itr = system._AllUsers.begin();
	vector<User*>::const_iterator itrEnd = system._AllUsers.end();
	for (int i=0; itr != itrEnd; ++itr, i++)
	{
		outFile << typeid(*system._AllUsers[i]).name() + 6 << endl;
		outFile << **itr << endl;
	}

    outFile.close();
}
void UserInterface::getData()
{
    string fileName, erase;
    int numOfUsers;
	
    ifstream inFile("AllUsers.txt" , ios::in);
	if(inFile.is_open())
	{
		inFile >> numOfUsers;
	
		system._AllUsers.clear();
		system._AllUsers.reserve(numOfUsers);

		for (int i = 0; i < numOfUsers; i++)
		{
			char type[System::MAX_NAME];
			inFile >> type;
			getline(inFile, erase);
			if (strcmp(type, typeid(Seller).name() + 6) == 0)
			{
				User* newSeller = new Seller(inFile);
				system += (*newSeller);
			}
			else if (strcmp(type, typeid(Customer).name() + 6) == 0)
			{
				User* newCustomer = new Customer(inFile);
				system += (*newCustomer);
			}
			else if (strcmp(type, typeid(SellerCustomer).name() + 6) == 0)
			{
				User* newSellerCustomer = new SellerCustomer(inFile);
				system += (*newSellerCustomer);
			}
		}
		inFile.close();
	}
}



//--------------------------------------------MENU--------------------------------------------------------//

void UserInterface::printMenu()
{
	cout << endl << endl;
	cout << "*** Below are the menu options, please press the number of the action you would like to do *** " << endl;
    cout << "1- Add customer\n";		// using operator +=
    cout << "2- Add seller\n";			// using operator +=
    cout << "3- Add customer-seller\n"; // using operator +=
    cout << "4- Add item to seller\n";
    cout << "5- Add feedback to seller\n";
    cout << "6- Add item to customers cart\n";
    cout << "7- Create an order\n";
    cout << "8- Pay order\n";
	cout << "9- Display all customers \n";
    cout << "10-Display all sellers \n";
    cout << "11-Display all customers that are also sellers \n";
    cout << "12-Display all users from a specific type \n";
    cout << "13-Search a product by name\n";
	cout << "14-Compare two customers based on the price of their cart\n";	// using operator >
	cout << "15-EXIT SYSTEM\n";

}
void UserInterface::activateAction(int action)
{
    switch (action)
    {
        case 1:
        {
            addNewUser(action);
			break;
        }
        case 2:
        {
            addNewUser(action);
			break;
        }
        case 3:
        {
            addNewUser(action);
            break;
        }
        case 4:
        {
			if (system.getCurrentNumOfSellers() == 0 && system.getCurrentNumOfSellerCustomer()==0)
			{
				cout << "ERROR: NO SELLERS IN SYSTEM" << endl;
				return;
			}
			addProductToSeller(); 
			break;
        }
        case 5:
        {
			if (checkExistenceOfUsers())
				addFeedback();
			break;
        }
        case 6:
        {
			if (checkExistenceOfUsers())
				addProductToCustomersCart();

			break;
        }
        case 7:
        {
			if (checkExistenceOfUsers())
				makeAnOrder(); 
			break;
        }
        case 8:
        {
			if (checkExistenceOfUsers())
				payOrder(); 		
			break;
        }
        case 9:
        {
            if (system.getCurrentNumOfCustomers() == 0)
            {
                cout << "ERROR: NO CUSTOMERS IN SYSTEM" << endl;
                return;
            }
            displayCustomers();
			break;
        }
        case 10:
        {
			if (system.getCurrentNumOfSellers() == 0)
			{
				cout << "ERROR: NO SELLERS IN SYSTEM" << endl;
				return;
			}
            displaySellers(); 
			break;
        }
        case 11:
        {
            if(system.getCurrentNumOfSellerCustomer() == 0)
            {
                cout << "ERROR: NO CUSTOMERS-SELLERS IN SYSTEM" << endl;
                return;
            }
            displaySellerCustomer();
            break;
        }
        case 12:
        {
            if(system.getCurrentNumOfUsers() == 0)
            {
                cout << "ERROR: NO USERS IN SYSTEM" << endl;
                return;
            }
            DisplayUsers();
            break;
        }
        case 13:
        {
			if ((system.getCurrentNumOfSellers() + system.getCurrentNumOfSellerCustomer()) == 0)
			{
				cout << "ERROR: NO SELLERS IN SYSTEM" << endl;
				return;
			}
				searchProducts();
			break;
        }
		case 14:
		{
			compareTwoCustomers();
			break;

		}
		case 15:
		{
			saveData();
			cout << "Users are saved to file named -AllUsers.txt-\n        GOODBYE! ";
			exit(-1);
		}
        default:
        {
            cout << "No action was chosen! Please choose again a valid action";
        }
		break;
    }
}

//--------------------------------------------------------------------------------------------------------//

//--------------------(1)(2)(3)----------------------ADD USER--------------------------------------------------//

void UserInterface::addNewUser(int type)
{
	string username;
	string password;


	username = defineNewUsername();
	password = defineNewPassword();
	Address address = defineNewAddress();

    if(type == 1)// customer
    {
        User* newCustomer = new Customer(address, username, password);
        system+=(*newCustomer);
    }
    else if (type == 2) // seller
	{
		User* newSeller = new Seller(address, username, password);
		system+=(*newSeller);
	}
    else if(type==3) // customer-seller
    {
        User* newSellerCustomer = new SellerCustomer(Seller(address, username, password), Customer(address, username, password));
        system+=(*newSellerCustomer);
    }
}

void UserInterface::cleanBuffer()
{
	int c;

	do
	{
		c = getchar();

	} while (c != '\n');

}

string UserInterface::defineNewUsername()
{
	string name;
	bool input = false;

	cout << "\nLet's create a user!\n";

	cout << "Please enter a proper username: ";
	while (!input)
	{
		cleanBuffer();
		getline(cin, name);
		if (system.checkUsername(name.c_str()) == false)
		{
			cout << "Oops! Something went wrong, please try a diffrerent username!\n";
		}
		else
			input = true;
	}
	return name;
}

string UserInterface::defineNewPassword()
{
	string password;
	bool toContiue = false;

	while (!toContiue)
	{
		cout << "Please enter a valid password (over 8 characters) : ";

		cin >> password;
		if (strlen(password.c_str()) >= 8)
			toContiue = true;
		else 
			cout << "password is too short " << endl;
	}
	return password;
}

Address UserInterface::defineNewAddress()
{
	string country;
	string city;
	string street;
	int houseNumber;
	int zipCode;
	cleanBuffer();
	cout << "\nPlease enter the following information for the user's address: \n";
	
	cout << "Country: ";
	getline(cin, country);

	cout << "City: ";
	getline(cin, city);

	cout << "Street: ";
	getline(cin, street);

	cout << "House Number: ";
	cin >> houseNumber;

	cout << "Zip Code: ";
	cin >> zipCode;

	return Address(country, city, street, zipCode, houseNumber);

}

//----------------------------------------------------------------------------------------------------------//


//---------------------(4)------------------------ADD PRODUCT TO SELLER------------------------------------//

void UserInterface::addProductToSeller()
{
	string productName;
	Product::eProductTypes eProductType;
	double  productPrice;
	Seller* wantedSeller;

	productName = defineNewProductName();
	eProductType = chooseProductType();
	productPrice = defineProductPrice();
	wantedSeller = chooseSeller();

	Product* product = new Product(productName, eProductType, productPrice, wantedSeller);
	wantedSeller->addProduct(product);
}

Seller* UserInterface::chooseSeller()
{
	int serialnum;
	bool toContinue=true;
	while (toContinue)
	{
		displaySellers();
		displaySellerCustomer();
		cout << "Enter the serial number of the seller: ";
		cin >> serialnum;
		for (int i = 0; i < system.getCurrentNumOfUsers();i++)
		{
			Seller* seller = dynamic_cast<Seller*>(system.getAllUsers()[i]);
			if (seller)
			{
				if (serialnum==seller->getSerialNum())
					return seller;
			}
		}
		cout << endl << "ERROR: INCORRECT NUMBER" << endl;
	}
}



double UserInterface::defineProductPrice()
{
	double price;

	cout << "Please enter the price of the new product: ";
	cin >> price;

	return price;
}

Product::eProductTypes UserInterface::chooseProductType()
{
	int type;
	cout << "Please choose the product's type: \n";
	cout << "Press 0 for 'Kids' \n";
	cout << "Press 1 for 'Electronics' \n";
	cout << "Press 2 for 'Office' \n";
	cout << "Press 3 for 'Clothing' \n";

	cin >> type;

	return (Product::eProductTypes)type;
}

string UserInterface::defineNewProductName()
{
	string name;

	cout << "Please enter a product name: ";
	cleanBuffer();
	getline(cin, name);

	return name;
}

//----------------------------------------------------------------------------------------------------//


//-------------------(5)-----------------------ADD FEEDBACK-------------------------------------------//

void UserInterface::addFeedback()
{
	char date[30];
	time_t curtime;
	time(&curtime);
	strcpy(date, ctime(&curtime));
	char content[System::MAX_CONTENT];
	int numOfProduct, i = 0, score, toContinue = 1;
	Customer* customer;
	Seller* seller;
	while (toContinue == 1)
	{
		customer = chooseCustomer();
		if (customer->getCurrentNumOfProdutsInShoppingHistory() == 0 )
		{
			cout << "ERROR:customer didnt buy anything yet" << endl;
			cout << "If you want to choose a different number press 1, to return to menu press 0" << endl;
			cin >> toContinue;
			if (toContinue == 0)
				return;
		}
		else
			break;
	}

	while (toContinue)
	{
		customer->printShoppingHistory();
		cout << "Please choose the item the feedback is on" << endl;
		cin >> numOfProduct;
		if (numOfProduct <= 0 || numOfProduct > customer->getCurrentNumOfProdutsInShoppingHistory())
		{
			cout << "ERROR: the number you chose is invalied" << endl;
			cout << "If you want to choose a different number press 1, to return to menu press 0" << endl;
			cin >> toContinue;
			if (toContinue == 0)
				return;
		}
		else
			break;
	}

	while (i < system.getCurrentNumOfSellers() + system.getCurrentNumOfSellerCustomer())
	{
		seller = dynamic_cast<Seller*>(system._AllUsers[i]);
		if (seller)
		{
			if (seller == customer->getShoppingHistory()[numOfProduct - 1]->getSeller())
			{
				cout << "Please write the feedback content (max characters" << System::MAX_CONTENT << ")" << endl;
				cleanBuffer();
				cin.getline(content, System::MAX_CONTENT);
				cout << endl << "Please give the seller score from 1 to 5" << endl;
				cin >> score;
				seller->getAllFeedbacks() += new Feedback(content, customer->getShoppingHistory()[numOfProduct - 1], customer, score, date);
				break;
			}
			i++;
		}
	}
}

//---------------------------------------------------------------------------------------------------//



//-------------------(6)----------------ADDING PRODUCT TO CUSTOMER'S CART---------------------------//

void UserInterface::addProductToCustomersCart()
{

	int toContinue = 1;
	while (toContinue)
	{

		Customer* wantedCustomer = chooseCustomer();
		Product* wantedProduct = chooseProduct();
		if (wantedProduct == NULL)
			return;

		wantedCustomer->getCart().addP(wantedProduct);
		cout << "If you want to add another product press 1, else press 0" << endl;
		cin >> toContinue;
	}

}

Customer* UserInterface::chooseCustomer()
{
	int serialnum;
	bool toContinue = true;
	while (toContinue)
	{
		displayCustomers();
		displaySellerCustomer();
		cout << "Enter the serial number of the customer: ";
		cin >> serialnum;
		for (int i = 0; i < system.getCurrentNumOfUsers();i++)
		{
			Customer* customer = dynamic_cast<Customer*>(system.getAllUsers()[i]);
			if (customer)
			{
				if (serialnum ==customer->getSerialNum())
					return customer;
			}
		}
		cout << endl << "ERROR: INCORRECT NAME" << endl;
	}
}

Product* UserInterface::chooseProduct()
{
	bool toContinue = true;
	int numOfSeller, numOfProduct, stop=1;
	Seller* seller;

	seller = chooseSeller();
	seller->printProducts();

	while (toContinue)
	{
		cout << "Please enter the number of the wanted product: ";
		cin >> numOfProduct;
		if (numOfProduct <= 0 || numOfProduct > seller->getNumOfProducts())
		{
			cout << endl << "ERROR: the number you chose is incorrect" << endl;
			cout << "If you want to choose a different product press 1, To return to menu press 0" << endl;
			cin >> stop;
			if (!stop)
				return NULL;
		}
		else
			toContinue = false;
	}
	
	Product* wantedProduct = seller->getAllProduct()[numOfProduct - 1];
	return wantedProduct;
}

//---------------------------------------------------------------------------------------------------//



//--------------(7)------------------------MAKING AN ORDER-------------------------------------------//

void UserInterface::makeAnOrder()
{
	int numOfItem, toContinue = 1;

	Customer* customer=chooseCustomer();


	while (toContinue == 1 && customer->getCart().getCurrentNumberOfItems() > 0)
	{
		customer->getCart().print();
		cout << "Please choose the number of item to add the order" << endl;
		cin >> numOfItem;

		if (numOfItem > customer->getCart().getCurrentNumberOfItems() || numOfItem <= 0)
			cout << "ERROR: NUMBER OF ITEM IS INVALIED" << endl;
		else
		{
			customer->getOrder().addP(customer->getCart().getAllProduct()[numOfItem - 1]);
			customer->getCart().removeP(numOfItem - 1);
		}

		cout << "If you want to add another product to order press 1, else press 0" << endl;
		cin >> toContinue;
	}

	if (customer->getCart().getCurrentNumberOfItems() == 0)
		cout << "Customer's cart is empty" << endl;

}

//--------------------------------------------------------------------------------------------------//



//---------------------(8)--------------PAY ORDER---------------------------------------------------//

void UserInterface::payOrder()
{
	Customer* wantedCustomer;
	int toContinue = 1;
	while (toContinue)
	{
		wantedCustomer = chooseCustomer();

		if (wantedCustomer->getOrder().getCurrentNumberOfItems() == 0)
		{
			cout << "Customer's order is empty" << endl;
			cout << "Press 1 if you want to choose other customer or 0 if you want to go bak to menu" << endl;
			cin >> toContinue;
			if (toContinue == 0)
				return;
		}
		else
			toContinue = 0;
	}
	wantedCustomer->getOrder().print();
	for (int i = 0;i < wantedCustomer->getOrder().getCurrentNumberOfItems();i++)
		wantedCustomer->addProductToShoppingHistory(wantedCustomer->getOrder().getAllProduct()[i]);
	wantedCustomer->getOrder().reset();
}

//-------------------------------------------------------------------------------------------------//


//----------------(9)(10)(11)(12)---------------------DISPLAY USERS---------------------------------------//

void UserInterface::displayCustomers() const
{
	Customer* customer;
	int j = 1;
	for (int i = 0;i < system.getCurrentNumOfUsers(), j<= system.getCurrentNumOfCustomers();i++)
	{
		if (strcmp(typeid((*system._AllUsers[i])).name(), typeid(Customer).name()) == 0)
		{
			customer = dynamic_cast<Customer*>(system._AllUsers[i]);
			cout << "---------CUSTOER #" << j << "---------\n";
			customer->print();
			cout << endl;
			j++;
		}
	}
}
void UserInterface::displaySellers() const
{
	Seller* seller;
	int j = 1;
	for (int i = 0;i < system.getCurrentNumOfUsers(), j<=system._currentNumOfSellers;i++)
	{
		if (strcmp(typeid((*system._AllUsers[i])).name(), typeid(Seller).name())==0)
		{
			seller = dynamic_cast<Seller*>(system._AllUsers[i]);
			cout << "---------SELLER #" << j << "---------\n";
			seller->print();
			cout << endl;
			j++;
		}
	}
}
void UserInterface::displaySellerCustomer() const
{
	SellerCustomer* sellerCustomer;
	int j = 1;
	for (int i = 0;i < system.getCurrentNumOfUsers(), j <= system.getCurrentNumOfSellerCustomer();i++)
	{
		sellerCustomer = dynamic_cast<SellerCustomer*>(system._AllUsers[i]);
		if (sellerCustomer)
		{
			cout << "---------CUSTOMER-SELLER #" << j << "---------\n";
			sellerCustomer->print();
			cout << endl;
			j++;
		}
	}
}
void UserInterface::DisplayUsers() const
{
    int type, flag=1;
    while (flag)
    {
        cout << "Please Choose the type of user you would like to display:\n 1-Customers\n 2-Sellers\n 3-Customers-Sellers\n";
        cin >> type;
        if(type==1)
        {
            if(system.getCurrentNumOfCustomers() == 0)
            {
                cout << "No customers in the system yet, please choose other type of user\n";
                continue;
            }
            else
            {
                displayCustomers();
            }
        }
        else if(type==2)
        {
            if(system.getCurrentNumOfSellers() == 0)
            {
                cout << "No sellerd in the system yet, please choose other type of user\n";
                continue;
            }
            else
            {
                displaySellers();
            }
        }
        else if(type == 3)
        {
            if(system.getCurrentNumOfSellerCustomer() == 0)
            {
                cout << "No customers-seller in the system yet, please choose other type of user\n";
                continue;
            }
            else
            {
                displaySellerCustomer();
            }
        }
        else
        {
            cout << "wrong input, please try again!\n";
            continue;
        }
        cout << "would you like to display another type? press 1 if you do, 0 id you don't\n";
        cin >> flag;
    }


}
//-------------------------------------------------------------------------------------------------//


//---------------------(13)----------------SEARCH PRODUCT BY NAME----------------------------------//

void UserInterface::searchProducts() 
{
	int counter = 0;
	char productName[System::MAX_NAME];
	cout << "Please enter the name of the product you are searching for " << endl;
	cleanBuffer();
	cin.getline(productName, System::MAX_NAME);

	for (int i = 0; i < system.getCurrentNumOfUsers();i++)
	{
		Seller* seller = dynamic_cast<Seller*>(system.getAllUsers()[i]);
		SellerCustomer* sellerCustomer = dynamic_cast<SellerCustomer*>(system.getAllUsers()[i]);

		if (seller)
		{
			for (int j = 0; j < seller->getNumOfProducts();j++)
			{
				if (strcmp(seller->getAllProduct()[j]->getProductName().c_str(), productName) == 0)
				{
					cout << endl << "--------PRODUCT #" << counter + 1 << " --------" << endl;
					cout << (*seller->getAllProduct()[j]);
					counter++;
					cout << endl << "-------THE SELLER IS:" << endl;
					seller->print();
					for (int i = 0; i < seller->getNumOfFeedbacks();i++)
						cout << (*seller->getAllFeedbacks().getArray()[i]);

				}
			}
		}

	}
	if (counter == 0)
		cout << "No results!" << endl;
}

//-------------------------------------------------------------------------------------------------//


//---------------------(14)---------------COMPARE TWO CUSTOMERS------------------------------------//

void UserInterface::compareTwoCustomers() 
{
	cout << "Please choose the first customer: \n";
	Customer* customer1 = chooseCustomer();
	cout << "Please choose the second customer: \n";
	Customer* customer2 = chooseCustomer();

	int res = (*customer1 > *customer2);
	if (res > 0)
		cout << "Customer " << customer1->getUserName().c_str() << " cart's is more expensive" << endl;
	else if(res < 0)
		cout << "Customer " << customer1->getUserName().c_str() << " cart's is more expensive" << endl;
	else
		cout << "Customer " << customer1->getUserName().c_str() << " and Customer " << customer2->getUserName().c_str() << " have the same cart total price" << endl;
}


//-------------------------------------------------------------------------------------------------//


bool UserInterface::checkExistenceOfUsers() const
{
	if (system.getCurrentNumOfUsers() == 0)
	{
		cout << "ERROR: NO USERS IN SYSTEM" << endl;
		return false;
	}
	return true;
}




