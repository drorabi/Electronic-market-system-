#ifndef __ARRAY_H
#define __ARRAY_H

#include <iostream>
using namespace std;
#pragma warning(disable:4996)


template<class T>
class Array
{
private:
	int		_logical;
	int		_physical;
	T** 	_arr;
	char	_delimiter;

public:
	Array(int size = 1, char delimiter = ' ');
	Array(const Array& other);
	Array(Array&& other);
	~Array();

	int getLogical() const {return _logical; }
	T** getArray() const {return _arr; }
	const Array& operator=(const Array& other);
    const Array& operator+=(T* newVal);
    T** Realloc();

	friend ostream& operator<<(ostream& os, const Array& arr)
	{
		for (int i = 0; i < arr._logical ;i++)
			os << arr._arr[i] << arr.delimiter;
		return os;
	}
};



template<class T>
Array<T>::Array(int size, char delimiter)
	: _physical(size), _logical(0), _delimiter(delimiter), _arr(nullptr)
{
	_arr = new T*[_physical];
}


template<class T>
Array<T>::Array(const Array& other) : _arr(nullptr)
{
	*this = other;
}

template<class T>
Array<T>::Array(Array&& other)
{
	this->_logical = other._logical;
	this->_physical = other._physical;
	this->_delimiter = other._delimiter;
	this->_arr = other._arr;
	other._arr = nullptr;
}

template<class T>
Array<T>::~Array()
{
	for(int i=0; i<_logical;i++)
	    delete _arr[i];
	delete[]_arr;
}

template<class T>
const Array<T>& Array<T>::operator=(const Array& other)
{
	if (this != &other)
	{
		delete[]_arr;
		this->_logical = other._logical;
		this->_physical = other._physical;
		this->_delimiter = other._delimiter;
		_arr = new T*[_physical];
		for (int i = 0; i < _logical; i++)
		{
			_arr[i] = other._arr[i];
		}
	}
	return *this;
}

template<class T>
 const Array<T>& Array<T>::operator+=(T* newVal)
{
	 
	if (_logical == _physical)
	{
		_physical*=2;
		_arr=Realloc();
	}
	    _arr[_logical++]= newVal;

	return *this;
}

template <class T>
T** Array<T>::Realloc()
{
    T** newArr = new T*[_physical];

    for (int i = 0; i < _logical; i++)
        newArr[i] = _arr[i];

    delete[]_arr;

    return newArr;
}

#endif // __ARRAY_H



