#ifndef __SYSTEM_H
#define __SYSTEM_H

#include <cmath>
#include <iostream>
#include "Seller.h"
#include "Customer.h"
#include "SellerCustomer.h"
#include <vector>

using namespace std;




class System
{
public:


	//------------------Constructor   Destructor--------------------------------//
	System(const string& name= string(), vector<User*> AllUsers =  vector<User*>());
	System(const System& other);
	System(System&& other);
	~System();

	//-------------------OPERATORS---------------------//
	const System& operator=(const System& other);
	const System& operator+=( User& user);

	

	//----------------getters-----------------------//
	const string&         getName() const { return _name; }
	vector<User*> 		getAllUsers() const {return _AllUsers;}
	int                 getCurrentNumOfCustomers() const { return _currentNumOfCustomers; }
	int                 getCurrentNumOfSellers() const { return _currentNumOfSellers; }
	int                 getCurrentNumOfSellerCustomer() const {return _currentNumOfSellerCustomer; }
	int                 getCurrentNumOfUsers() const { return _AllUsers.size(); }
	
	//----------------Setters-----------------------//
	bool  setName(const string& name);
	bool  checkUsername(const char* str);
	

	friend class UserInterface;
	static const int MAX_NAME = 50;
	static const int MAX_CONTENT = 200;

	
	//--------------Attributes------------------//
private:
    int         _currentNumOfCustomers;
	int         _currentNumOfSellers;
	int         _currentNumOfSellerCustomer;
	string       _name;
	vector<User*>      _AllUsers;
};

#endif // System.h