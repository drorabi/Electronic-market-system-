#ifndef __CART_H
#define __CART_H

#include "Product.h"
#include <cmath>
#pragma warning (disable:4996)
#include<vector>

class Cart
{
public:

	//------------------Construstor---Destructor-----------------------------//
	Cart();
	Cart(const Cart& other);
	Cart(Cart&& other);
	~Cart();

	//-------------------------------Operator-----------------------------//
	const Cart& operator=(const Cart& other);

	//---------------------------print-------------------------------//
	void      print() const;

	void addP(Product* newP);
	void removeP(int index);

	//--------------------Getters----------------------//
	vector<Product*>  getAllProduct() const { return _All_Products; }
	int               getCurrentNumberOfItems() const { return _All_Products.size(); }
	double            getPrice() const { return _price	;}

	friend class Customer;

	//-------------------Attributes-----------------//
private:
	vector<Product*>  _All_Products;
	double     _price;
};

#endif // __CART_H