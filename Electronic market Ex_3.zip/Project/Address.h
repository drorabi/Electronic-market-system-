#ifndef __ADDRESS_H
#define __ADDRESS_H

#include <iostream>
using namespace std;
#include<string>
#include <fstream>


class Address
{
public:

	//------------------Constructor---Destructor-----------------------------//
	Address(const string& country=string(), const string& city = string(), const string& street = string(),  const int zipCode=0, const int houseNumber=0);
	Address(ifstream& in);
	Address(const Address& other) { *this = other; }
	//--------------------Operator-----------------//
	friend ostream& operator<<(ostream& os, const Address& address);
	const Address& operator=(const Address& other);


	//------------------Getters--------------------//
	const string& getCountry() const { return _country; }
	const string& getCity() const { return _city; }
	const string& getStreet() const { return _street; }
	int           getHouseNumber() const { return _houseNumber; }
	int           getZipCode() const { return _zipCode; }

	//------------------Setters--------------------//
	bool setHouseNumber(const int houseNumber);
	bool setZipCode(int zipCode);
	void setCountry(const std::string& country);
	void setCity(const std::string& city);
	void setStreet(const std::string& street);

	friend class Customer;
	friend class Seller;

	//-------------------Attributes-----------------//
private:
	string _country;
	string _city;
	string _street;
	int        _houseNumber;
	int        _zipCode;
};

#endif // Address.h