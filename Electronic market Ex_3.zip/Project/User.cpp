#include "User.h"

int User::userSerialNumCounter = 1000;
//---------------------Constructor Destructor----------------//
User::User(Address address, const string&  username, const string&  password)
	:_address(address), _userSerialNum(0)
{
	setUserName(username);
	setPassword(password);
	setSerialNumber();
}

User::User(ifstream& in) :_address(in)
{
	string erase;
	in >> _userSerialNum;
	getline(in, erase);
	getline(in, _username);
	getline(in, _password);
}

User::User(const User& other)
{
	*this = other;
}

User::User(const User&& other)
{
	_address = other._address;
	_username = other._username;
	_password = other._password;
	_userSerialNum = other._userSerialNum;
}

//-----------------print-----------------------------------------//
void User::print() const
{
	cout << "Username: " << _username.c_str() << endl;
	cout << "User Serial Number: " << _userSerialNum << endl;
	cout << "Password: " << _password.c_str() << endl;
	cout <<  "Address: " <<  _address;
}

//-----------------------Operator------------------------------//
const User& User::operator=(const User& other)
{
	if (this != &other)
	{
		this->_address = other._address;
		this->_username = other._username;
		this->_password =other._password;
		_userSerialNum = other._userSerialNum;
	}
	return *this;
}


ostream& operator<<(ostream& out, const User& user) {

	if (typeid(out) == typeid(ofstream))
		out << user._address << user._userSerialNum << endl << user._username << endl << user._password;

	else
	{
		cout << "Username: " << user._username.c_str() << endl;
		cout << "User Serial Number: " << user._userSerialNum << endl;
		cout << "Password: " << user._password.c_str() << endl;
		cout << "Address: " << user._address;
	}
	return out;
}


//----------------------Setters------------------------------//
void User::setUserName(const string& username)
{
	_username = username;
}
void User::setPassword(const string& password)
{
	_password = password;
}

void User::setSerialNumber()
{
	_userSerialNum = userSerialNumCounter;
}

