
#ifndef _SELLERCUSTOMER_H
#define _SELLERCUSTOMER_H

#include "Seller.h"
#include "Customer.h"
using namespace std;

class SellerCustomer : public Seller, public Customer {
public:
	SellerCustomer(const Seller &seller = Seller(),const Customer &customer = Customer()) : User(seller.getAddress(),seller.getUserName(),seller.getPassWord()), Seller(seller), Customer(customer){}
	SellerCustomer(ifstream& in) : User(in), Seller(), Customer() {};
	~SellerCustomer() {}

    virtual void print() const override;
};


#endif //_SELLERCUSTOMER_H
