#include "Cart.h"
using namespace std;



//------------------Construstor---Destructor-----------------------------//
Cart::Cart():_price(0)
{}
Cart::Cart(const Cart& other)
{
	*this = other;
}
Cart::Cart(Cart && other)
{
	_All_Products = other._All_Products;
}

Cart::~Cart()
{
	_All_Products.clear();
}

//-----------------------operator----------------------------//
const Cart & Cart::operator=(const Cart & other)
{
	if (this != &other)
	{
		_All_Products.clear();
		_All_Products = other._All_Products;
	}
	return *this;
}


//---------------------PRINT---------------------------------//
void Cart::print() const
{
	int i = 1;
	if (_All_Products.size() == 0)
	{
		cout << "Cart is empty" << endl;
		return;
	}
	vector<Product*>::const_iterator itr = _All_Products.begin();
	vector<Product*>::const_iterator itrEnd = _All_Products.end();
	for (; itr!= itrEnd; ++itr)
	{
		cout << "-------------ITEM #" << i  << "-----------" << endl;
		cout << (**itr);
		i++;
	}
}

void Cart::addP(Product * newP)
{
	_All_Products.push_back(newP);
	_price += newP->getProductPrice();
}

void Cart::removeP(int index)
{
	_price -= _All_Products[index]->getProductPrice();
	_All_Products.erase(_All_Products.begin() + index);
}



