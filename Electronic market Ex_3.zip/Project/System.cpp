#include <iostream>
#include "System.h"
using namespace std;
#pragma warning (disable:4996)

//------------------------------------CONSTRUCTOR  DESTRUCTOR------------------------//

System::System(const string& name, vector<User*> AllUsers)
	: _currentNumOfCustomers(0), _currentNumOfSellers(0), _currentNumOfSellerCustomer(0),_AllUsers(AllUsers)
{
	bool flag;
	flag=setName(name);

}

System::System(const System& other)
{
	*this = other;
}

System::System(System && other)
{
	_currentNumOfCustomers = other._currentNumOfCustomers;
	_currentNumOfSellers = other._currentNumOfSellers;
	_currentNumOfSellerCustomer = other._currentNumOfSellerCustomer;
	_AllUsers = other._AllUsers;
}

System::~System()
{
	for (int i = 0;i < _AllUsers.size();i++)
		delete _AllUsers[i];
}

//-------------------OPERATORS---------------------//
const System & System::operator=(const System & other)
{
	if (this != &other)
	{
		_currentNumOfCustomers = other._currentNumOfCustomers;
		_currentNumOfSellers = other._currentNumOfSellers;
        _currentNumOfSellerCustomer = other._currentNumOfSellerCustomer;
		_name = other._name;
		_AllUsers.clear();
		for (int i = 0;i < _AllUsers.size();i++)
			_AllUsers.push_back(other._AllUsers[i]);
	}
	return *this;
}

const System& System::operator+=( User& user)
{
	_AllUsers.push_back(&user);

	if (strcmp(typeid(user).name(), typeid(Seller).name()) == 0)
		_currentNumOfSellers++;

	if (strcmp(typeid(user).name(), typeid(Customer).name()) == 0)
		_currentNumOfCustomers++;

	if (strcmp(typeid(user).name(), typeid(SellerCustomer).name()) == 0)
		_currentNumOfSellerCustomer++;

	User::userSerialNumCounter++;

	return *this;
}



//---------------------Setters----------------------------//
bool System::setName(const string& name)
{
	_name = name;
	return true;
}


bool System::checkUsername(const char* str)
{
	for (int i = 0; i < _AllUsers.size();i++)
	{
		if (strcmp(str, _AllUsers[i]->getUserName().c_str()) == 0)
			return false;
	}
	return true;
}







