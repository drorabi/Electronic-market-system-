#ifndef __SELLER_H
#define __SELLER_H

#include <iostream>
#include <cmath>
#include "User.h"
#include "Feedback.h"
#include "Array.h"
#include<vector>


class Seller : virtual public User
{
public:

	//------------------Constructor Destructor--------------------------------//
	Seller(const Address& address = Address(), const string& username = string(), const string& password = string()) : User(address, username, password),_AllFeedbacks(Array<Feedback>()), _score(3) {}
	Seller(ifstream& in) : User(in) {}
	Seller(const Seller& other);
	Seller(Seller&& other);
	~Seller();

	//------------------------PRINTING-------------------------------------//
	virtual void print() const override;
	void printProducts() const;
	void printFeedbacks() const;

	//----------------------operator-------------------------------------//
	const Seller& operator=(const Seller& other);

	//--------------------ADD FEEDBACK AND PRODUCT-----------------------//
	void       addProduct(Product* newProduct);


	//----------------------------Setters---------------------------------//


	//------------------Getters--------------------//
	Array<Feedback>&   getAllFeedbacks() { return _AllFeedbacks; }
	vector<Product*>   getAllProduct() const { return _AllProducts; }
	int                getNumOfProducts() const { return _AllProducts.size(); }
	int            getNumOfFeedbacks() const { return _AllFeedbacks.getLogical(); }
	int            getScore() const { return _score; }

	//-------------------Attributes-----------------//
protected:

	Array<Feedback>     _AllFeedbacks;
	vector<Product*>    _AllProducts;
	int                 _score;
};

#endif // Seller.h