#include <iostream>
#pragma warning (disable:4996)

using namespace std;
#include "Address.h"


//------------------Construstor  Destructor-----------------------------//

Address::Address(const string& country, const string& city, const string& street, const int zipCode, const int houseNumber)
{
	bool flag;
	flag = setHouseNumber(houseNumber);
	flag = setZipCode(zipCode);
	setCountry(country);
	setCity(city);
	setStreet(street);
}

Address::Address(ifstream& in)
{
	string erase;
	getline(in, _country);
	getline(in, _city);
	getline(in, _street);
	in >> _houseNumber;
	in >> _zipCode;
	getline(in, erase);
}

//--------------------operator-----------------------//
const Address & Address::operator=(const Address & other)
{
    if (this != &other)
    {
        _houseNumber = other._houseNumber;
        _zipCode = other._zipCode;
        _street = other._street;
        _city = other._city;
        _country = other._country;
    }
    return *this;
}

ostream& operator<<(ostream& os, const Address& address)
{
	if(typeid(os) == typeid(ofstream))
	    os << address._country << endl << address._city << endl << address._street << endl << address._houseNumber << endl << address._zipCode << endl;
	else
        os << "  " << address._houseNumber << " " << address._street.c_str() << endl << "  " << address._city.c_str() << " " << address._zipCode << endl << "  " << address._country.c_str() << endl;
	return os;
}

//------------------------setters--------------------------//


bool Address::setHouseNumber(const int houseNumber)
{
	if (houseNumber < 0)
		return false;

	_houseNumber = houseNumber;
	return true;
}

bool Address::setZipCode(int zipCode)
{
	if (zipCode < 0)
		return false;

	_zipCode = zipCode;
	return true;
}
void Address::setCountry(const std::string& country)
{
	_country = country;
}
void Address::setCity(const std::string& city)
{
	_city = city;
}
void Address::setStreet(const std::string& street)
{
	_street = street;
}



