
#include "Customer.h"
#pragma warning (disable:4996)

using namespace std;


//------------------Constructor---Destructor-----------------------------//

Customer::Customer(const Customer& other)
	:User(other),_cart(other._cart),_order(other._order)	
{
	*this = other;
}
Customer::Customer(Customer&& other) : User(other)
{
	_order = other._order;
	_cart = other._cart;
	_shoppingHistory = other._shoppingHistory;
}

Customer::~Customer()
{}



//----------------PRINTIG------------------------//
void Customer::print() const
{
    User::print();
	cout << "Number of items in cart: " << _cart.getCurrentNumberOfItems() << endl;
	cout << "Number of items purchased: " << _shoppingHistory.size() << endl;
}

void Customer::printShoppingHistory() const
{
	int i = 1;
	if (_shoppingHistory.size() == 0)
	{
		cout << "Customer did not purchase any product yet" << endl;
		return;
	}
	vector<Product*>::const_iterator itr = _shoppingHistory.begin();
	vector<Product*>::const_iterator itrEnd = _shoppingHistory.end();
	for (; itr != itrEnd; ++itr)
	{
		cout << "-------------ITEM #" << i << "-----------" << endl;
		cout << (**itr);
		i++;
	}
}

//----------------------operator------------------------------------//
const Customer & Customer::operator=(const Customer & other)
{
	if (this != &other)
	{
		_shoppingHistory.clear();
		for (int i = 0;i < _shoppingHistory.size();i++)
			_shoppingHistory.push_back(other._shoppingHistory[i]);
	}
	return *this;
}

int Customer::operator>(Customer& other)
{
	if (this->getCart().getPrice() > other.getCart().getPrice())
		return 1;
	else if (this->getCart().getPrice() < other.getCart().getPrice())
		return -1;
	else
		return 0;
}

//-----------------ADD TO SHOPPING HISTORY-----------------//
void Customer::addProductToShoppingHistory(Product* new_product)
{
	_shoppingHistory.push_back(new_product);
}





