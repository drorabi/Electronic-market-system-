#ifndef __PRODUCT_H
#define __PRODUCT_H

#include <cmath>
#include <iostream>
using namespace std;
#pragma warning (disable:4996)
#include <string>

class Seller;

class Product
{
public:
	static int productSerialNumCounter;


	//-----------------------------TYPES----------------------------//
	enum eProductTypes { Kids, Electronics, Office, Closing };
	const char* types[4] = { "Kids", "Electronics", "Office", "Clothing" };

	//-------------------Construstor Destructor-------------------------//
	Product(const string& name = string(), eProductTypes type= (eProductTypes)0, double price=0, Seller* seller=nullptr);
	Product(const Product& other);
	Product(Product&& other);
	


	//------------------------operator---------------------//
	const Product& operator=(const Product& other);
	friend ostream& operator<<(ostream& os, const Product& product);

	//---------------------Setters---------------------------//
	void setProductName(const string& name);
	void setProductType(eProductTypes type);
	bool setProductPrice(double price);
	void setProductSerialNumber();
	void setSeller(Seller* seller);

	

	//---------------------Getters---------------------------//
	const string&   getProductName() const { return _name; }
	eProductTypes getProductType() const { return _type; }
	double        getProductPrice() const { return _price; }
	int           getProductSerialNumber() const { return _serialNumber; }
	Seller*       getSeller() { return _seller  ;}


	//----------------------Attributes----------------------//
private:
	string      _name;
	eProductTypes _type;
	double        _price;
	int           _serialNumber;
	Seller*       _seller;

};

#endif // __PRODUCT_H
