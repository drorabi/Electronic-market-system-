#ifndef __ORDER_H
#define __ORDER_H

#include <cmath>
#include "Cart.h"
#include "Product.h"
#pragma warning (disable:4996)
#include<vector>

class Order
{
public:

	//------------------Construstor Destructor--------------------------------//
	Order();
	Order(const Order& order);
	Order(Order&& other);
	~Order();

	//--------------------------printing-------------------------------//
	void print() const;

	//---------------------------operator-----------------------------//
	const Order& operator=(const Order& other);


	//-------------------------Getters-------------------------------//
	double            getPrice() const { return _price; }
	vector<Product*>  getAllProduct() const { return _AllProducts; }
	int               getCurrentNumberOfItems() const { return _AllProducts.size(); }

	friend class Customer;

	void addP(Product* newP);
	void reset();
	//-------------------Attributes-----------------//
private: 
	vector<Product*>  _AllProducts;
	double     _price;
};

#endif // __ORDER_H