#include "Order.h"
using namespace std;


//---------------------CONSTRUCTOR DESTRUCTOR-------------------------//
Order::Order():_price(0)
{}
Order::Order(const Order& other)
{
	*this = other;
}

Order::Order(Order && other)
{
	_AllProducts = other._AllProducts;
	_price = other._price;
}

Order::~Order()
{
	_AllProducts.clear();
}


//------------------PRINTING--------------------//
 void Order::print() const
 {
		 int i = 1;
		 if (_AllProducts.size() == 0)
		 {
			 cout << "Order is empty" << endl;
			 return;
		 }
		 cout << endl << "-----------ORDER HAVE SHIPPED------------" << endl;

		 vector<Product*>::const_iterator itr = _AllProducts.begin();
		 vector<Product*>::const_iterator itrEnd = _AllProducts.end();
		 for (; itr != itrEnd; ++itr)
		 {
			 cout << "-------------ITEM #" << i << "-----------" << endl;
			 cout << (**itr);
			 i++;
		 }

	 cout << "---------- TOTAL PRICE IS: " << _price << "$----------" << endl;
 }

 //---------------------------operator-----------------------------//
 const Order & Order::operator=(const Order & other)
 {
	 if (this != &other)
	 {
		 this->_price = other._price;
		 _AllProducts.clear();
		 for (int i = 0; i < other.getAllProduct().size();i++)
		 {
			 _AllProducts.push_back(other._AllProducts[i]);
		 }
	 }
	 return *this;
 }

 void Order::addP(Product * newP)
 {
	 _AllProducts.push_back(newP);
	 _price += newP->getProductPrice();
 }

 void Order::reset()
 {
	 _price = 0;
	 _AllProducts.clear();
 }





