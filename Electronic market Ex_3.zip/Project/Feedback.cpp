#include "Feedback.h"
#include <ctime>
#pragma warning (disable:4996)

using namespace std;


//-------------Constructor---Destructor-----------------------//
Feedback::Feedback(const string& feedback, Product* product, Customer* customer, int score, const string& date)
:_product(product),_customer(customer), _5StarReview(0)
{
	bool flag;
	setContent(feedback);
	flag=setReview(score);
	_date= date;
}
Feedback::Feedback(const Feedback & other)
{
	*this = other;
}
Feedback::Feedback(Feedback && other)
{
	*this = other;
}





//-------------------------operator---------------------------//
const Feedback & Feedback::operator=(const Feedback & other)
{
	if (this != &other)
	{
		_5StarReview = other._5StarReview;
		_customer = other._customer;
		_product = other._product;
		_content = other._content;
		_content, other._date;
		return *this;
	}
}
ostream& operator<<(ostream& os, const Feedback& feedback)
{
	os  << endl << "Customer: ";
	os << feedback._customer->getUserName() << endl;
	os << "Date:" << feedback._date;
	os << "Feedback:" << endl << feedback._content << endl;
	os << "Review over all:" << endl << feedback._5StarReview << "/5 stars" << endl;
	return os;
}



//-------------------Setters-----------------------//
void Feedback::setContent(const string&  feedback)
{
	_content = feedback;
}
bool Feedback::setReview(int review)
{
	if (review > 5 || review < 0)
		return false;
	_5StarReview = review;
	return true;
}
